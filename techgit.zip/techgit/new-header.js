$(document).ready(function () {
  $(window).scroll(function () {
    var scrollY = $(window).scrollTop();
    var viewPort = window.innerWidth >= 768 ? 375 : 183;
    if (scrollY > viewPort) {
      $("#header").css("top", "-65px")
      $("#header1").css("top", "0");
    } else {
      $("#header").css("top", "0px");
      $("#header1").css("top", "-65px");
    }
  });
});
// sidenav end ============================================= 