var images = document.querySelectorAll('.image-click');
var modal = document.getElementById('myModal');
var modalImg = document.getElementById('modalImg');
var closeButton = document.querySelector('.close');

images.forEach(function(image) {
  image.onclick = function() {
    modal.style.display = 'block';
    modalImg.src = this.src;
  };
});
closeButton.onclick = function() {
  modal.style.display = 'none';
};

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = 'none';
  }
};
  
//   <!-- ===bhk strating price and sqft change start====== -->
 
function showPricing(bhk) {
  const numberOfBHKs = [i]; 
  const bhkElements = [
    'oneBHKDetails',
    'twoBHKDetails',
    'threeBHKDetails',
    'fourBHKDetails',
    'fiveBHKDetails'
  ];
  for (let i = 0; i < numberOfBHKs; i++) {
    document.getElementById(bhkElements[i]).style.display = 'none';
  }
  
  if (bhk >= 1 && bhk <= numberOfBHKs) {
    document.getElementById(bhkElements[bhk - 1]).style.display = 'flex';
  }
}
//   <!-- ===bhk strating price and sqft change end====== -->
// gallery and floorplans swiper changes start========-
function showSwipess(Swipe) {
    const elementsToShow = [
      'Gallery',
      'MasterPlan',
      'TypicalPlan',
      'Location',
      '1bhkdetails',
      '2bhkdetails',
      '3bhkdetails',
      '4bhkdetails',
      '5bhkdetails',
      'villadetails'
    ];
  
    elementsToShow.forEach(elementId => {
      const element = document.getElementById(elementId);
      if (element) {
        element.style.display = 'none';
      }
    });
  
    const indexToShow = Swipe - 1; 
    if (indexToShow >= 0 && indexToShow < elementsToShow.length) {
      const selectedElementId = elementsToShow[indexToShow];
      const selectedElement = document.getElementById(selectedElementId);
      if (selectedElement) {
        selectedElement.style.display = 'block';
      }
    }
  }
//   =======================
// ===========Read more option============  
    function myFunction() {
      var dots = document.getElementById("dots");
      var moreText = document.getElementById("more");
      var btnText = document.getElementById("myBtn");

      if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
      } else {
        dots.style.display = "none";
        btnText.innerHTML = "Read less";
        moreText.style.display = "inline";
      }
    }
  
// <!-- // ===== property detail active js start ====== -->
  
                var buttonContainer = document.getElementById("hshighlight1");
                var neobutton = buttonContainer.getElementsByClassName("btns");
                for (var i = 0; i < neobutton.length; i++) {
                  neobutton[i].addEventListener("click", function () {
                    var neocurrent = document.getElementsByClassName("hsactive");
                    neocurrent[0].className = neocurrent[0].className.replace(" hsactive", "");
                    this.className += " hsactive";
                  });
                }
  
// <!-- // ===== property detail active js end ====== -->
//   <!-- // ===== property detail active js start ====== -->
  
    var buttonContainer = document.getElementById("up1");
    var neobutton = buttonContainer.getElementsByClassName("btnsss1");
    for (var i = 0; i < neobutton.length; i++) {
      neobutton[i].addEventListener("click", function () {
        var neocurrent = document.getElementsByClassName("neonn");
        neocurrent[0].className = neocurrent[0].className.replace(" neonn", "");
        this.className += " neonn";
      });
    }
  
//   <!-- // ===== property detail active js end ====== -->

// property-right start==============================
$(document).ready(function () {
    $(window).scroll(function () {
      var scrollY = $(window).scrollTop();
      if (scrollY > 0) {  
        $(".propdetail-right").css("top","20px");
        $(".propdetail-right").css("position", "sticky");
      } 
      if (scrollY >= 900) {  
        $(".propdetail-right").css("top", "65px");
      }
      else if (scrollY >= 2500) {  
        $(".propdetail-right").css("position", "sticky");
      }
    else{
      $(".propdetail-right").css("display", "flow");
          }
    });
  });
  // propright end==============================
  // ======property detail header start =======
  $(document).ready(function () {
    $(window).scroll(function () {
      var scrollY = $(window).scrollTop();
      var windowWidth = window.innerWidth;
      var propdethead = $(".propdethead");
      if ((scrollY >= 900 && windowWidth >= 768) || (scrollY >= 660 && windowWidth <= 768)) {
        propdethead.css({
          "position": "fixed",
          "width": "97%"
        });
        if (scrollY >= 900 && windowWidth >= 768) {
          propdethead.css("top", "-10px");
        } 
        if (scrollY >= 660 && windowWidth <= 768) {
          propdethead.css("top", "17px");
        }
      } 
      else {
        propdethead.css({
          "position": "sticky",
          "top": "10px",
          "width":"100%"
        });
      }
    });
  });
  // ======property detail header end =======
  // -==========================================================================================
function initializeSwiper6(selector, slidesPerView, spaceBetween) {
    return new Swiper(selector, {
      slidesPerView: slidesPerView,
      spaceBetween: spaceBetween,
      lazy: true,
   
    freemode:true,
      pagination: {
        el: ".swiper-pagination",
        type: "fraction",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  }
  var swiper11 = initializeSwiper6(".mySwiper11", 1,30);

//   ==-=================================
  function commonNav(navId, widthValue) {
    const navElement = document.getElementById(navId);
    navElement.style.width = widthValue;
    navElement.style.display = widthValue === "0%" ? "none" : "block";
  }
  // ==============================================================================
  function initializeSwiper13(selector, slidesPerView, spaceBetween) {
    return new Swiper(selector, {
      slidesPerView: slidesPerView, // preview slider
      spaceBetween: spaceBetween,
      lazy: true,
    freemode:true,
    // autoplay: {
    //   delay: 2500,
    //   disableOnInteraction: false,
    // },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
        dynamicBullets: true,
      },
      breakpoints:{
        768:{
          slidesPerView:3,
        },
        500:{
          slidesPerView:2.5,
          spaceBetween:15
        },
        250:{
          slidesPerView:2,
        }
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  }
    var swiper14 = initializeSwiper13(".mySwiper13", 3, 25);
    var swiper15 = initializeSwiper13(".mySwiper14", 3, 25);

