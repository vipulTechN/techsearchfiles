const page1 =document.getElementById("page1dets");
const page1a=document.getElementById("page1next");
const page2 =document.getElementById("page2dets");
const page2a =document.getElementById("page2prev");
const page2b =document.getElementById("page2next");
const page3 =document.getElementById("page3dets");
const page3a =document.getElementById("page3prev");
const page3b =document.getElementById("page3next");
const page4 =document.getElementById("page4dets");
const page4a =document.getElementById("page4prev");
const submitBtn = document.querySelector(".submit");
const progressText = document.querySelectorAll(".step p");
const progressCheck = document.querySelectorAll(".step .check");
const bullet = document.querySelectorAll(".step .bullet");
let current = 1;

page1a.addEventListener("click",function(){
  page2.style.display="block";
  page1.style.display="none";
  bullet[current - 1].classList.add("active");
  progressCheck[current - 1].classList.add("active");
  progressText[current - 1].classList.add("active");
  current += 1;
})

page2a.addEventListener("click",function(){
  page2.style.display="none";
  page1.style.display="block";
  bullet[current - 2].classList.remove("active");
  progressCheck[current - 2].classList.remove("active");
  progressText[current - 2].classList.remove("active");
  current -= 1;
})

page2b.addEventListener("click",function(){
  page3.style.display="block";
  page2.style.display="none";
  bullet[current - 1].classList.add("active");
  progressCheck[current - 1].classList.add("active");
  progressText[current - 1].classList.add("active");
  current += 1;
})
page3a.addEventListener("click",function(){
  page3.style.display="none";
  page2.style.display="block";
  bullet[current - 2].classList.remove("active");
  progressCheck[current - 2].classList.remove("active");
  progressText[current - 2].classList.remove("active");
  current -= 1;
})
page3b.addEventListener("click",function(){
  page4.style.display="block";
  page3.style.display="none";
  bullet[current - 1].classList.add("active");
  progressCheck[current - 1].classList.add("active");
  progressText[current - 1].classList.add("active");
  current += 1;
})
page4a.addEventListener("click",function(){
  page4.style.display="none";
  page3.style.display="block";
  bullet[current - 2].classList.remove("active");
  progressCheck[current - 2].classList.remove("active");
  progressText[current - 2].classList.remove("active");
  current -= 1;
})
submitBtn.addEventListener("click", function(){
  bullet[current - 1].classList.add("active");
  progressCheck[current - 1].classList.add("active");
  progressText[current - 1].classList.add("active");
  current += 1;
  setTimeout(function(){
    alert("Your Property Listed SuccesFully 👍");
    location.reload();
  },800);
});